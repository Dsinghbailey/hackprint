/**added to RendererSVG.prototype.background ***
this.drawingContext.clearRect(0, 0, this.width, this.height);
**/
/** fix for parent SVG**/
p5.Element.prototype.parent = function(p) {
  if (typeof p === 'string') {
    p = document.getElementById(p);
  } else if (p instanceof p5.Element) {
    p = p.elt;
  }
  if(this.elt.wrapper){
  p.appendChild(this.elt.wrapper);
  }
  else
  {
     p.appendChild(this.elt);
  } 
  return this;
};

/** make canvas creation easier**/
var WIDTH_SCALAR_FOR_RESIZING=1;
var HEIGHT_SCALAR_FOR_RESIZING=1;
 var _createCanvas = p5.prototype.createCanvas;
    p5.prototype.createDesign = function(w, h) {
      	WIDTH_SCALAR_FOR_RESIZING=w;
      	HEIGHT_SCALAR_FOR_RESIZING=h;
      	var containerWidth=$('#canvasContainer').width();
  		var containerHeight=$('#canvasContainer').height();
        var graphics = _createCanvas.apply(this, [w*containerWidth,h*containerHeight, SVG]);
      	graphics.parent(canvasContainer);
        return this._renderer;
    };
/* set postion*/
  p5.prototype.positionDesign = function() {
    if (arguments.length === 0){
      return { 'x' : this._renderer.elt.offsetLeft , 'y' : this._renderer.elt.offsetTop };
    }else{
      this._renderer.elt.style.position = 'absolute';
      this._renderer.elt.style.left = arguments[0]*100+'%';
      this._renderer.elt.style.top = arguments[1]*100+'%';
      this._renderer.x = arguments[0];
      this._renderer.y = arguments[1];
      return this;
    }
  };

/*product size to image (not on editor yet)*/
function pSizeToImage(prodtitle)
  {
    var variantName = prodtitle;
    var imgWidth=$("#ProductPhotoImg").width();
    var imgHeight=$("#ProductPhotoImg").height();
	var leftMagin=$("#ProductPhotoImg").css("marginLeft");
    $("#canvasContainer").css('marginLeft',leftMagin);
    var rightMagin=$("#ProductPhotoImg").css("marginRight");
    $("#canvasContainer").css('marginRight',rightMagin);
    
    if (variantName.indexOf("Womens Tee")>-1)
    {
      $("#canvasContainer").width(imgWidth*.395);
     $("#canvasContainer").height(imgHeight*.47);
     $("#canvasContainer").css({left: imgWidth*.305, top: imgHeight*.185});
      
    }
    else if (variantName.indexOf("Unisex Longsleeve")>-1)
    {
     $("#canvasContainer").width(imgWidth*.36);
     $("#canvasContainer").height(imgHeight*.48);
     $("#canvasContainer").css({left: imgWidth*.325, top: imgHeight*.19});
    }
    else if(variantName.indexOf("Unisex Fleece")>-1)
    {
     $("#canvasContainer").width(imgWidth*.33);
     $("#canvasContainer").height(imgHeight*.48);
     $("#canvasContainer").css({left: imgWidth*.335, top: imgHeight*.16});
    }
    else
    {
     $("#canvasContainer").width(imgWidth*.37);
     $("#canvasContainer").height(imgHeight*.52);
     $("#canvasContainer").css({left: imgWidth*.305, top: imgHeight*.215});

    }  
  }
/* product grid sizeto Image*/
 function pgridSizeToImage(prodnum, prodtitle, topString, leftString)
  {
    var variantName = prodtitle;
    var imgWidth=$("#ProductPhoto"+prodnum).width();
    var imgHeight=$("#ProductPhoto"+prodnum).height();
    var leftMagin=$("#ProductPhoto"+prodnum).css("marginLeft");
    $('#canvasContainer'+prodnum).css('marginLeft',leftMagin);
    
    //place svg using top and left
	$('#SVG'+prodnum).css('top', topString);
    $('#SVG'+ prodnum).css('left', leftString);
    
    if (variantName.indexOf("Womens Tee")>-1)
    {
     $('#canvasContainer'+prodnum).width(imgWidth*.395);
     $('#canvasContainer'+prodnum).height(imgHeight*.47);
     $('#canvasContainer'+prodnum).css({left: imgWidth*.305, top: imgHeight*.185});
      
    }
    else if (variantName.indexOf("Unisex Longsleeve")>-1)
    {
     $('#canvasContainer'+prodnum).width(imgWidth*.36);
     $('#canvasContainer'+prodnum).height(imgHeight*.48);
     $('#canvasContainer'+prodnum).css({left: imgWidth*.325, top: imgHeight*.19});
    }
    else if(variantName.indexOf("Unisex Fleece")>-1)
    {
     $('#canvasContainer'+prodnum).width(imgWidth*.33);
     $('#canvasContainer'+prodnum).height(imgHeight*.48);
     $('#canvasContainer'+prodnum).css({left: imgWidth*.335, top: imgHeight*.16});
    }
    else
    {
      $('#canvasContainer'+prodnum).width(imgWidth*.37);
      $('#canvasContainer'+prodnum).height(imgHeight*.52);
      $("#canvasContainer" + prodnum).css({left: imgWidth*.305, top: imgHeight*.215});
      
    }
  }
/* product cart sizeto Image*/
  function cartSizeToImage(idx, title, topString, leftString)
  {
    var variantName =title;
    var imgWidth=$("#cartProductPhoto"+idx).width();
    var imgHeight=$("#cartProductPhoto"+idx).height();
    var rightMagin=$("#cartProductPhoto"+idx).css("marginRight");
    $container=$("#canvasContainer"+idx);
    $container.css('marginRight',rightMagin);
    //place svg using top and left
	$('#SVG'+idx).css('top', topString);
    $('#SVG'+ idx).css('left', leftString);
    
    if (variantName.indexOf("Womens Tee")>-1)
    {
     $container.width(imgWidth*.395);
     $container.height(imgHeight*.47);
     $container.css({left: imgWidth*.305, top: imgHeight*.185});
      
    }
    else if (variantName.indexOf("Unisex Longsleeve")>-1)
    {
     $container.width(imgWidth*.36);
     $container.height(imgHeight*.48);
     $container.css({left: imgWidth*.325, top: imgHeight*.19});
    }
    else if(variantName.indexOf("Unisex Fleece")>-1)
    {
     $container.width(imgWidth*.33);
     $container.height(imgHeight*.48);
     $container.css({left: imgWidth*.335, top: imgHeight*.16});
    }
    else
    {
     $container.width(imgWidth*.37);
     $container.height(imgHeight*.52);
     $container.css({left: imgWidth*.305, top: imgHeight*.215});
    }
    
  }
